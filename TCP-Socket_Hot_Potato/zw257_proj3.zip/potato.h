//
// Created by Brandon on 3/17/2022.
//

#ifndef TCP_SOCKET_HOT_POTATO_POTATO_H
#define TCP_SOCKET_HOT_POTATO_POTATO_H

struct _potato {
    int remaining_counter;
    int player_list[513];
} potato;


#endif //TCP_SOCKET_HOT_POTATO_POTATO_H


