package com.zw257.bean;

public class Q4_arg {
	private String team_state;
	private String team_color;


	public String getTeam_color() {
		return team_color;
	}

	public void setTeam_color(String team_color) {
		this.team_color = team_color;
	}

	public String getTeam_state() {
		return team_state;
	}

	public void setTeam_state(String team_state) {
		this.team_state = team_state;
	}



}

